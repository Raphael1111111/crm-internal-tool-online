const ONE_WEEK_MS = 7 * 24 * 60 * 60 * 1000;

chrome.runtime.onInstalled.addListener(function() { scheduleWeeklyAlarm(); updateBadge(null); });
chrome.runtime.onStartup.addListener(function() { scheduleWeeklyAlarm(); updateBadge(null); });

chrome.tabs.onActivated.addListener(function(info) {
  chrome.tabs.get(info.tabId, function(tab) { if (tab) handleTabChange(tab); });
});
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete' && tab) handleTabChange(tab);
});

function handleTabChange(tab) {
  const url = tab.url || '';
  const isProfile = url.includes('linkedin.com/in/') ||
                    url.includes('linkedin.com/sales/people/') ||
                    url.includes('linkedin.com/sales/lead/');
  chrome.storage.local.set({ currentProfileUrl: isProfile ? url : null });
  updateBadge(isProfile ? url : null);
}

// Badge priority: 1=profiel(oranje)  2=>7d niet gescrapet(rood)  3=leeg
function updateBadge(profileUrl) {
  if (profileUrl) {
    chrome.action.setBadgeText({ text: '●' });
    chrome.action.setBadgeBackgroundColor({ color: '#E8820C' });
    chrome.action.setTitle({ title: 'LinkedIn → n8n — profiel gevonden!' });
    return;
  }
  chrome.storage.local.get(['lastScrapedAt'], function(data) {
    const overdue = !data.lastScrapedAt || (Date.now() - data.lastScrapedAt) > ONE_WEEK_MS;
    if (overdue) {
      chrome.action.setBadgeText({ text: '!' });
      chrome.action.setBadgeBackgroundColor({ color: '#A32D2D' });
      chrome.action.setTitle({ title: 'LinkedIn → n8n — tijd om te scrapen!' });
    } else {
      chrome.action.setBadgeText({ text: '' });
      chrome.action.setTitle({ title: 'LinkedIn → n8n' });
    }
  });
}

chrome.storage.onChanged.addListener(function(changes) {
  if (changes.lastScrapedAt || changes.currentProfileUrl) {
    chrome.storage.local.get(['currentProfileUrl'], function(data) {
      updateBadge(data.currentProfileUrl || null);
    });
  }
});

function scheduleWeeklyAlarm() {
  const now = new Date();
  const target = new Date();
  const day = now.getDay();
  let daysUntilFriday = (5 - day + 7) % 7;
  if (daysUntilFriday === 0 && now.getHours() >= 10) daysUntilFriday = 7;
  target.setDate(now.getDate() + daysUntilFriday);
  target.setHours(10, 0, 0, 0);
  chrome.alarms.clear('fridayReminder', function() {
    chrome.alarms.create('fridayReminder', { when: target.getTime() });
  });
  chrome.alarms.create('dailyCheck', { periodInMinutes: 60 * 24 });
}

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'fridayReminder') {
    chrome.notifications.create({
      type: 'basic', iconUrl: 'icon48.png',
      title: '⏰ Tijd om te scrapen!',
      message: 'Het is vrijdag — open Sales Navigator en scrape je nieuwe HR leads.',
      priority: 2
    });
    scheduleWeeklyAlarm();
  }
  if (alarm.name === 'dailyCheck') {
    chrome.storage.local.get(['currentProfileUrl'], function(data) {
      updateBadge(data.currentProfileUrl || null);
    });
  }
});
