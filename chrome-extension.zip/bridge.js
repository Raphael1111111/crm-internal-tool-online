// bridge.js — runs on the CRM page (crm.internal-tool.online).
// Reads the n8n key + env the user typed into the CRM and shares them with the
// extension so the user doesn't have to type the key twice.
//
// The CRM writes these to its own localStorage on unlock:
//   li_crm_bridge_key  → the n8n API key
//   li_crm_bridge_env  → 'prod' | 'test'
// It removes them on lock. We mirror that into chrome.storage.local.

(function () {
  const KEY_BRIDGE = 'li_crm_bridge_key';
  const ENV_BRIDGE = 'li_crm_bridge_env';

  function syncFromPage() {
    let key = null, env = null;
    try {
      key = localStorage.getItem(KEY_BRIDGE);
      env = localStorage.getItem(ENV_BRIDGE);
    } catch (e) { return; }

    if (key) {
      chrome.storage.local.set({
        n8nKeyFromCRM: key,
        n8nEnvFromCRM: (env === 'test' ? 'test' : 'prod'),
        n8nKeyFromCRMAt: Date.now()
      });
    } else {
      // CRM locked / no key → drop the shared copy
      chrome.storage.local.remove(['n8nKeyFromCRM', 'n8nEnvFromCRM', 'n8nKeyFromCRMAt']);
    }
  }

  // Initial read, then poll while the tab is open (cheap, same-origin).
  syncFromPage();
  setInterval(syncFromPage, 2000);
})();
