// ── n8n endpoints (prod default / test) ──────────────────────────────────────
const N8N_URLS = {
  prod: 'https://n8n.dev.hoorayhr.io/webhook/56bc510a-38d4-410f-ab5c-41ca63e825f8',
  test: 'https://n8n.dev.hoorayhr.io/webhook-test/56bc510a-38d4-410f-ab5c-41ca63e825f8'
};
let cfg = { manualKey:'', env:'prod', salesNavUrl:'', lang:'en' };
let crmKey='', crmEnv=null, crmUser='';
let scrapedLeads=[];
let activeTabInfo={ kind:'other', url:'' }; // kind: salesnav | profile | other
let extCampaigns=null;                       // cached list of campaigns (= existing lead `tags`)
let profileCrmDone=false, profileCrmLead=null; // result of the auto "already in our CRM?" check

function L(k, vars){ let s=extT(cfg.lang,k); if(vars){ Object.keys(vars).forEach(n=>{ s=s.replace('{'+n+'}',vars[n]); }); } return s; }

// ── person matching across URL forms ──────────────────────────────────────────
// The same person can be stored under a Sales-Navigator URL (…/sales/lead/ACwAA…) and visited
// on the normal profile (…/in/slug). The member id in Sales-Nav URLs (ACwAA…) and the profile
// urn id embedded in the normal profile page (ACoAA…) differ ONLY in their 3-char type prefix —
// the payload is the same member. So each lead/row gets a set of keys (normalised URL(s) +
// id-tail + public /in/ URL when the page revealed one) and two records are the same person
// when ANY key overlaps. Pure frontend — no n8n/Sheet change.
function liNormUrl(u){
  return String(u||'').split(/[?#]/)[0].replace(/\/+$/,'').toLowerCase()
    .replace(/^https?:\/\//,'').replace(/^www\./,'').replace(/^[a-z]{2,3}\.linkedin\.com/,'linkedin.com');
}
function liIdTail(id){ return /^AC[a-zA-Z0-9_-]{15,}$/.test(String(id||''))?('id:'+String(id).slice(3).toLowerCase()):null; }
// REALITY CHECK (verified by decoding real pairs): the Sales-Nav lead id (ACwAA…) and the profile
// id (ACoAA…) of the SAME person do NOT share the full tail. Decoded: byte 1 is the surface type
// (0x2c lead / 0x2a profile), bytes 2–8 are the identical member number, the trailing 20 bytes are
// a per-surface signature that DIFFERS. So the only cross-form key is the member "stem" =
// base64 chars 3–11. (The full-tail key is kept for rows that store the same form twice.)
function liIdStem(id){ return /^AC[a-zA-Z0-9_-]{30,}$/.test(String(id||''))?('stem:'+String(id).substr(3,9).toLowerCase()):null; }
function liAddId(keys,id){ const t=liIdTail(id); if(t) keys.add(t); const s=liIdStem(id); if(s) keys.add(s); }
function liKeysOf(o){ // o: a scraped lead OR a CRM row (any of url / linkedinUrl / publicUrl / memberId)
  const keys=new Set();
  [o&&o.url, o&&o.linkedinUrl, o&&o.publicUrl].forEach(u=>{
    if(!u) return;
    const n=liNormUrl(u); if(n) keys.add('url:'+n);
    let m=String(u).match(/linkedin\.com\/sales\/(?:lead|people)\/([^,\/?#]+)/i);
    if(m) liAddId(keys, m[1]);
    m=String(u).match(/linkedin\.com\/in\/([^\/?#]+)/i);
    if(m) liAddId(keys, decodeURIComponent(m[1]));
  });
  if(o&&o.memberId) liAddId(keys, o.memberId);
  return keys;
}
function liSame(a,b){ for(const k of a){ if(b.has(k)) return true; } return false; }
function effectiveKey(){ return crmKey||cfg.manualKey||''; }
function effectiveEnv(){ return (crmKey&&crmEnv)?crmEnv:cfg.env; }
function effectiveUrl(){ return N8N_URLS[effectiveEnv()==='test'?'test':'prod']; }
function keySource(){ return crmKey?'CRM':(cfg.manualKey?'manual':null); }

// ── boot ──────────────────────────────────────────────────────────────────
chrome.storage.local.get(['n8nKey','n8nEnv','salesNavUrl','extLang','lastScrapedAt','n8nKeyFromCRM','n8nEnvFromCRM','n8nUserFromCRM','n8nLangFromCRM'], function(d){
  cfg.manualKey=d.n8nKey||''; cfg.env=d.n8nEnv==='test'?'test':'prod';
  cfg.salesNavUrl=d.salesNavUrl||'';
  // language: an explicit popup choice wins; otherwise follow the CRM's UI language (bridged)
  cfg.lang=EXT_I18N[d.extLang]?d.extLang:(EXT_I18N[d.n8nLangFromCRM]?d.n8nLangFromCRM:'en');
  crmKey=d.n8nKeyFromCRM||''; crmEnv=d.n8nEnvFromCRM||null; crmUser=d.n8nUserFromCRM||'';
  document.getElementById('cfg-key').value=cfg.manualKey;
  document.getElementById('cfg-salesnav').value=cfg.salesNavUrl;
  buildLangSelect();
  applyExtI18n();
  updateKeyStatus(); updateLastScraped(d.lastScrapedAt); reflectConfigState();
  detectTab();
});

chrome.storage.onChanged.addListener(function(ch){
  if(ch.n8nKeyFromCRM||ch.n8nEnvFromCRM||ch.n8nUserFromCRM){
    crmKey=ch.n8nKeyFromCRM?ch.n8nKeyFromCRM.newValue||'':crmKey;
    crmEnv=ch.n8nEnvFromCRM?ch.n8nEnvFromCRM.newValue||null:crmEnv;
    crmUser=ch.n8nUserFromCRM?ch.n8nUserFromCRM.newValue||'':crmUser;
    updateKeyStatus(); updateEnvUI(); reflectConfigState();
  }
});

document.getElementById('settings-btn').addEventListener('click',()=>document.getElementById('settings').classList.toggle('open'));
document.getElementById('cfg-save').addEventListener('click',saveConfig);
document.getElementById('env-toggle').addEventListener('click',toggleEnv);
document.getElementById('open-sales-nav').addEventListener('click',openSalesNav);
document.getElementById('scrape-btn').addEventListener('click',scrape);
document.getElementById('profile-btn').addEventListener('click',addCurrentProfile);
document.getElementById('lang-select').addEventListener('change',function(){ cfg.lang=this.value; chrome.storage.local.set({extLang:cfg.lang}); applyExtI18n(); });

function buildLangSelect(){
  const sel=document.getElementById('lang-select');
  sel.innerHTML=Object.keys(EXT_I18N).map(c=>`<option value="${c}" ${c===cfg.lang?'selected':''}>${EXT_I18N[c]._name}</option>`).join('');
}
function applyExtI18n(){
  document.getElementById('hdr-title').textContent=L('title');
  document.getElementById('hdr-sub').textContent=L('subtitle');
  document.getElementById('lbl-settings').textContent=L('settings');
  document.getElementById('lbl-key').textContent=L('keyManualLabel');
  document.getElementById('hint-key').textContent=L('keyManualHint');
  document.getElementById('lbl-salesnav').textContent=L('salesNavLabel');
  document.getElementById('hint-salesnav').textContent=L('salesNavHint');
  document.getElementById('cfg-save').textContent=L('saveSettings');
  document.getElementById('cfg-missing').textContent=L('cfgMissing');
  document.getElementById('open-sales-nav').textContent=L('openSalesNav');
  document.getElementById('scrape-btn').textContent=L('scrapeBtn');
  document.getElementById('profile-btn').textContent=L('profileBtn');
  updateKeyStatus(); updateEnvUI(); refreshContextText();
}

function saveConfig(){
  cfg.manualKey=document.getElementById('cfg-key').value.trim();
  cfg.salesNavUrl=document.getElementById('cfg-salesnav').value.trim();
  chrome.storage.local.set({n8nKey:cfg.manualKey,salesNavUrl:cfg.salesNavUrl},()=>{
    updateKeyStatus(); reflectConfigState();
    document.getElementById('settings').classList.remove('open');
    setStatus('ok',L('settingsSaved'));
  });
}
function toggleEnv(){
  if(crmKey&&crmEnv){ setStatus('warning',L('envFollowsCRM',{env:crmEnv==='test'?'Test':'Prod'})); return; }
  cfg.env=cfg.env==='prod'?'test':'prod';
  chrome.storage.local.set({n8nEnv:cfg.env},updateEnvUI);
}
function updateEnvUI(){
  const btn=document.getElementById('env-toggle'); const env=effectiveEnv(); const locked=!!(crmKey&&crmEnv);
  btn.textContent=(env==='test'?'🧪 Test':'⚙️ Prod')+(locked?' (CRM)':'');
  btn.classList.toggle('test',env==='test');
}
function updateKeyStatus(){
  const el=document.getElementById('key-status'); const src=keySource();
  if(!src){ el.textContent=L('keyNone'); el.className='key-status none'; return; }
  if(src==='CRM'){ el.textContent=L('keyFromCRM'); el.className='key-status crm'; }
  else { el.textContent=L('keyManual'); el.className='key-status manual'; }
}
function configReady(){ return !!effectiveKey(); }
function reflectConfigState(){
  document.getElementById('cfg-missing').style.display=configReady()?'none':'block';
  document.getElementById('scrape-btn').disabled=!configReady();
  document.getElementById('profile-btn').disabled=!configReady();
}
function openSalesNav(){ chrome.tabs.create({url: cfg.salesNavUrl || 'https://www.linkedin.com/sales/search/people'}); }

// ── detect what page we're on, show the right buttons ────────────────────────
async function detectTab(){
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const url=tab?.url||'';
    if(url.includes('linkedin.com/sales/search')||url.includes('linkedin.com/sales/lists')) activeTabInfo={kind:'salesnav',url};
    else if(url.match(/linkedin\.com\/in\//)||url.includes('linkedin.com/sales/people/')||url.includes('linkedin.com/sales/lead/')) activeTabInfo={kind:'profile',url};
    else activeTabInfo={kind:'other',url};
  } catch(e){ activeTabInfo={kind:'other',url:''}; }
  // show/hide buttons
  document.getElementById('profile-btn').style.display = activeTabInfo.kind==='profile'?'flex':'none';
  document.getElementById('scrape-btn').style.display  = activeTabInfo.kind==='profile'?'none':'flex';
  refreshContextText();
  if(activeTabInfo.kind==='profile' && configReady()) autoProfileChecks();
}

// ── on a profile: scrape once, open the panel right away, auto-check Pipedrive AND our CRM ──
// No click needed anymore: if the person is already in the CRM the message tools are enabled
// immediately (reflectProfileCrm); if not, the campaign + "Add to CRM" block is shown.
async function autoProfileChecks(){
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeProfileDOM});
    const lead=results?.[0]?.result;
    if(!lead||!lead.name) return; // scrape failed → the big button stays visible as the retry path
    lead.source='profile'; lead.linkedinUrl=lead.linkedinUrl||tab.url;
    scrapedLeads=[lead];
    document.getElementById('profile-btn').style.display='none'; // panel replaces the button
    renderResults(scrapedLeads,true);
    // Only claim a Pipedrive result once we actually know WHO this is. With just a bare name (no
    // member id and no company — a half-read page) a name-only Pipedrive lookup is a guess, so we
    // skip it and leave the "scroll/reload to read the full profile" hint instead of a misleading
    // "not in Pipedrive". The CRM check still runs: it matches by id/URL and is correct either way.
    if(lead.memberId || lead.newCompany) autoPipedriveCheck(lead);
    else { const pb=document.getElementById('pd-badge'); if(pb) pb.style.display='none'; }
    autoCrmCheck(lead);
  } catch(e){}
}
// LinkedIn shows out-of-network people as "Firstname L." — Pipedrive stores full names, so a
// name search on that is a guess, not a match. Such person-hits are treated as "uncertain":
// no auto "in Pipedrive" status, an amber badge instead of a hard warning, and a note on the lead.
function abbrevLastName(name){
  const p=String(name||'').trim().split(/\s+/);
  return p.length>=2 && /^[a-zà-þ]\.?$/i.test(p[p.length-1]);
}
// ── auto-check whether this profile already exists in Pipedrive ──────────────
async function autoPipedriveCheck(lead){
  const badge=document.getElementById('pd-badge'); if(!badge) return;
  badge.style.display='block'; badge.className='pd-badge checking'; badge.textContent='⏳ '+L('pdChecking');
  try {
    if(!lead){
      const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
      const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeProfileDOM});
      lead=results?.[0]?.result; if(lead) lead.linkedinUrl=lead.linkedinUrl||tab.url;
    }
    if(!lead||!lead.name){ badge.style.display='none'; return; }
    const key=effectiveKey();
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'pipedrive-check',apiKey:key,lead:{name:lead.name,newCompany:lead.newCompany||'',url:lead.linkedinUrl||''}}) });
    if(!resp.ok){ badge.style.display='none'; return; }
    const info=await resp.json();
    const pe=info.personExists, oe=info.orgExists;
    const unc=pe&&abbrevLastName(lead.name);
    if(pe||oe){
      const who=[(pe&&!unc)?L('pdPerson'):'',oe?L('pdOrg'):''].filter(Boolean).join(' + ');
      if(who){ badge.className='pd-badge warn'; badge.textContent='⚠️ '+L('pdInPd')+' '+who+(unc?(' · '+L('pdUncertain')):''); }
      else { badge.className='pd-badge checking'; badge.textContent='⚠️ '+L('pdUncertain'); }
    }
    else { badge.className='pd-badge ok'; badge.textContent='✓ '+L('pdNotInPd'); }
  } catch(e){ badge.style.display='none'; }
}
// ── auto-check whether this profile is ALREADY in our CRM (the Google Sheet) ──
// Pure frontend, reuses the existing `list` action (no n8n change). Matches via liKeysOf /
// liSame, so a person stored under a Sales-Nav URL is recognised on the normal profile too.
async function autoCrmCheck(lead){
  const badge=document.getElementById('crm-badge'); if(!badge||!lead) return;
  profileCrmDone=false; profileCrmLead=null;
  reflectProfileCrm(); // pending state: hide both the add block and the compose tools
  badge.style.display='block'; badge.className='pd-badge checking'; badge.textContent='⏳ '+L('crmChecking');
  try {
    const key=effectiveKey();
    const target=liKeysOf(lead);
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
    if(!resp.ok){ badge.style.display='none'; return; }
    const data=await resp.json(); const arr=(data&&Array.isArray(data.leads))?data.leads:[];
    // v3.9: rows soft-deleted in the CRM (status 'deleted') count as NOT in the CRM — the SDR
    // sees the add block again and re-adding resurrects the row (see resurrectDeletedRows).
    const match=target.size?arr.find(l=>l.status!=='deleted'&&liSame(target, liKeysOf(l))):null;
    profileCrmDone=true; profileCrmLead=match||null;
    if(match){
      const tags=Array.isArray(match.tags)?match.tags:safeArr(match.tags);
      badge.className='pd-badge ok';
      badge.textContent='✓ '+L('crmInCrm')+(match.status?(' ('+match.status+')'):'')+(tags.length?(' · '+tags.join(', ')):'');
      // v3.6: a re-scan that saw MORE (e.g. the SDR scrolled "Experience" into view and reopened
      // the popup) ENRICHES the stored row — note pieces the row doesn't have yet are appended and
      // an empty title/company is filled (list→sync, no n8n change). Volatile pieces (language
      // guess, degree, follower counts) are excluded and dedupe is by substring, so reopening the
      // popup twice never duplicates anything.
      try{
        const have=String(match.notes||'');
        const fresh=String(lead.notes||'').split(' • ').map(function(p){ return p.trim(); })
          .filter(function(p){ return p && !['🗣','🤝','👥'].some(function(v){ return p.indexOf(v)===0; }) && have.indexOf(p)<0; });
        if(fresh.length||(!match.title&&lead.title)||(!match.newCompany&&lead.newCompany)){
          const r=await syncLeadUpdate(lead,function(l){
            if(fresh.length) l.notes=(l.notes?l.notes+' • ':'')+fresh.join(' • ');
            if(!l.title&&lead.title) l.title=lead.title;
            if(!l.newCompany&&lead.newCompany) l.newCompany=lead.newCompany;
          });
          if(r&&r.ok){ profileCrmLead=r.lead; badge.textContent+=' · '+L('crmEnriched'); }
        }
      }catch(e){}
    } else {
      badge.className='pd-badge'; badge.style.background='var(--surface2)'; badge.style.color='var(--text2)';
      badge.textContent='＋ '+L('crmNotInCrm');
    }
  } catch(e){ badge.style.display='none'; profileCrmDone=true; profileCrmLead=null; }
  reflectProfileCrm();
}
function safeArr(s){ if(Array.isArray(s)) return s; try{ const a=JSON.parse(s); return Array.isArray(a)?a:[]; }catch(e){ return []; } }
// reflect the CRM-check result onto the rendered profile panel. Three states:
// pending → neither block (the badge shows "checking…"); in CRM → ONLY the compose tools;
// not in CRM → ONLY the campaign + "Add to CRM" block (no message UI before the person exists).
function reflectProfileCrm(){
  const pending=!profileCrmDone;
  const inCrm = profileCrmDone && !!profileCrmLead;
  const addWrap=document.getElementById('crm-add-wrap'); if(addWrap) addWrap.style.display=(pending||inCrm)?'none':'block';
  const comp=document.getElementById('ext-compose'); if(comp) comp.style.display=inCrm?'block':'none';
  const ms=document.getElementById('msg-sent-btn'); if(ms) ms.disabled=!inCrm;
  const pd=document.getElementById('pd-add-btn'); if(pd) pd.disabled=!inCrm;
  const hint=document.getElementById('ext-actions-hint'); if(hint) hint.style.display='none';
}
function refreshContextText(){
  chrome.storage.local.get(['lastScrapedAt'],function(d){
    const last=d.lastScrapedAt;
    if(!configReady()){ setStatus('warning',last?contextMsg():L('welcomeNoLast')); return; }
    setStatus('', contextMsg());
  });
}
function contextMsg(){
  if(activeTabInfo.kind==='profile') return L('onProfile');
  if(activeTabInfo.kind==='salesnav') return L('onSalesNav');
  return L('onOther');
}

// ── scrape Sales Navigator list ──────────────────────────────────────────────
async function scrape(){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('scrape-btn'); setStatus('loading',L('scraping')); btn.disabled=true; btn.textContent=L('busy');
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab.url||!tab.url.includes('linkedin.com/sales')){ setStatus('err',L('goToSalesNav')); resetScrapeBtn(); return; }
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeSalesNavDOM});
    const leads=results?.[0]?.result||[];
    if(!leads.length){ setStatus('err',L('noLeads')); resetScrapeBtn(); return; }
    scrapedLeads=leads.map(l=>({...l,source:'salesnav'}));
    const now=Date.now(); chrome.storage.local.set({lastScrapedAt:now}); chrome.action.setBadgeText({text:''}); updateLastScraped(now);
    setStatus('ok','✅ '+leads.length+L('foundLeads'));
    renderResults(scrapedLeads,false);
    btn.textContent=L('rescrape'); btn.disabled=false;
  } catch(e){ setStatus('err','❌ '+e.message); resetScrapeBtn(); }
}
function scrapeSalesNavDOM(){
  const clean=s=>(s||'').replace(/\s+/g,' ').trim();
  // language guess: geography + legal forms + stopword score (same logic as the profile scraper)
  const fold=t=>(' '+(t||'').toLowerCase()+' ').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[ëéè]/g,'e').replace(/ï/g,'i');
  const guessLang=t=>{
    const s=fold(t);
    let de=0, nl=0;
    if(/\b(germany|deutschland|austria|oesterreich|switzerland|schweiz|berlin|muenchen|munich|hamburg|frankfurt|koeln|cologne|stuttgart|duesseldorf|leipzig|dresden|hannover|nuernberg|bremen|dortmund|essen|bonn|mannheim|wien|vienna|graz|linz|salzburg|zuerich|zurich|basel|bern)\b/.test(s)) de+=3;
    if(/\b(netherlands|nederland|holland|belgium|belgie|amsterdam|rotterdam|utrecht|eindhoven|den haag|the hague|groningen|tilburg|breda|nijmegen|haarlem|arnhem|maastricht|leiden|zwolle|delft|antwerpen|antwerp|gent|ghent|brugge|leuven|hasselt|brussel|brussels)\b/.test(s)) nl+=3;
    if(/\bgmbh\b/.test(s)) de+=2;
    if(/\bb\.v\.|\bbv\b/.test(s)) nl+=2;
    de+=(s.match(/\b(und|der|das|ist|mit|fuer|bei|wir|nicht|eine|auch|auf|aus|werden|jahre|erfahrung|unternehmen|bereich|leiter|vertrieb|mitarbeiter|kunden|ueber|mehr|seit)\b/g)||[]).length;
    nl+=(s.match(/\b(en|het|van|voor|bij|wij|niet|een|ook|op|uit|worden|jaar|ervaring|bedrijf|medewerkers|verkoop|klanten|sinds|naar|onze|nieuwe|graag)\b/g)||[]).length;
    return (de>=2&&de>nl)?'German':((nl>=2&&nl>de)?'Dutch':'English');
  };
  const leads=[],seen=new Set();
  const selectors=['.artdeco-list__item','[data-view-name="search-results-entity-result-item"]','li.artdeco-list__item'];
  let items=[]; for(const sel of selectors){ items=Array.from(document.querySelectorAll(sel)); if(items.length)break; }
  if(!items.length){ const cards=new Set(); document.querySelectorAll('a[href*="/sales/people/"],a[href*="/sales/lead/"]').forEach(link=>{ const c=link.closest('li')||link.closest('[class*="result"]')||link.closest('[class*="item"]'); if(c)cards.add(c); }); items=Array.from(cards); }
  items.forEach(item=>{ try{
    const grab=sel=>{ const e=item.querySelector(sel); return e?clean(e.innerText):''; };
    const name=grab('[data-anonymize="person-name"]')||grab('.artdeco-entity-lockup__title span');
    if(!name||name.length<2||seen.has(name))return; seen.add(name);

    // current company — explicit field on the card
    let newCompany=grab('[data-anonymize="company-name"]');

    // headline / title — usually "Title at/·  Company"; strip the company off the tail
    const headline=grab('[data-anonymize="title"]')||grab('[data-anonymize="headline"]')||grab('.artdeco-entity-lockup__subtitle');
    let title=headline;
    if(title&&newCompany&&title.toLowerCase().endsWith(newCompany.toLowerCase())){
      title=clean(title.slice(0,title.length-newCompany.length).replace(/(?:\bat\b|\bbei\b|\bbij\b|[•·\-–|,])\s*$/i,''));
    } else if(!newCompany&&headline){
      const m=headline.split(/\s+(?:·|•|\||–|\bat\b|\bbei\b|\bbij\b)\s+/i);
      if(m.length>1){ title=clean(m[0]); newCompany=clean(m[m.length-1]); }
    }

    // location — this is what used to be (wrongly) written into oldCompany
    const location=grab('[data-anonymize="location"]')||grab('.artdeco-entity-lockup__caption');

    // previous company — ONLY when the card explicitly labels a past role (rare in the list view)
    let oldCompany='';
    const labelled=Array.from(item.querySelectorAll('[data-anonymize], .artdeco-entity-lockup__metadata, [class*="highlight"], [class*="spotlight"]')).map(e=>clean(e.innerText)).filter(Boolean);
    for(const tx of labelled){
      const m=tx.match(/^(?:past|previous(?:ly)?|formerly|vorher(?:ig)?|fr[üu]her|ehemalig|voorheen|voormalig)\s*[:\-–]\s*(.+)$/i);
      if(m){ const cand=clean(m[1]); if(cand&&cand.length<=70&&cand.toLowerCase()!==(newCompany||'').toLowerCase()){ oldCompany=cand; break; } }
    }

    // notes — roll up every useful bit of context we can see (incl. the location)
    const degree=grab('.artdeco-entity-lockup__degree')||grab('[data-anonymize="degree"]');
    // guess the person's main language from location + headline + company (so outreach can be in their language)
    const guessedLang=guessLang((location||'')+' '+(headline||'')+' '+(newCompany||''));
    const noteParts=[];
    if(location) noteParts.push('📍 '+location);
    noteParts.push('🗣 '+guessedLang);
    if(headline) noteParts.push(headline);
    if(degree) noteParts.push('🔗 '+degree);
    Array.from(item.querySelectorAll('.artdeco-entity-lockup__metadata, [class*="spotlight"], [class*="highlight"]')).forEach(e=>{ const tx=clean(e.innerText); if(tx&&tx.length<=160&&!noteParts.some(p=>p.indexOf(tx)>=0)) noteParts.push(tx); });

    const linkEl=item.querySelector('a[href*="/sales/people/"],a[href*="/sales/lead/"]');
    leads.push({ name, title, newCompany, oldCompany, size:'', linkedinUrl:linkEl?linkEl.href:'', notes:noteParts.join(' • ') });
  }catch(e){} });
  return leads;
}

// ── add a single normal-LinkedIn profile ─────────────────────────────────────
async function addCurrentProfile(){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('profile-btn'); btn.disabled=true; btn.textContent=L('busy');
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeProfileDOM});
    const lead=results?.[0]?.result;
    if(!lead||!lead.name){ setStatus('err',L('couldNotRead')); btn.disabled=false; btn.textContent=L('profileBtn'); return; }
    lead.source='profile'; lead.linkedinUrl=lead.linkedinUrl||tab.url;
    scrapedLeads=[lead];
    setStatus('', L('onProfile'));
    btn.style.display='none';           // panel replaces the button (same as the auto flow)
    renderResults(scrapedLeads,true);   // shows the campaign field + "Add to CRM" + compose tools
    autoPipedriveCheck(lead);
    autoCrmCheck(lead);                 // (re)confirm for THIS profile — drives the panel state

    btn.disabled=false; btn.textContent=L('profileBtn');
  } catch(e){ setStatus('err','❌ '+e.message); btn.disabled=false; btn.textContent=L('profileBtn'); }
}
function scrapeProfileDOM(){
  const clean=s=>(s||'').replace(/\s+/g,' ').trim();
  function txt(sel){ const el=document.querySelector(sel); return el?clean(el.innerText):''; }
  let name='', title='', company='', loc='', about='', network='', headNote='', tHead=false;
  // 1) JSON-LD structured data — LinkedIn embeds a Person schema on profile pages. This is far
  //    more stable than CSS class names (which LinkedIn reshuffles regularly and which caused
  //    the "Could not read this profile" failures).
  try{
    document.querySelectorAll('script[type="application/ld+json"]').forEach(sc=>{
      if(name) return;
      try{
        const data=JSON.parse(sc.textContent||'null');
        const nodes=[].concat((data&&data['@graph'])||data||[]);
        const p=nodes.find(n=>n&&(n['@type']==='Person'||(Array.isArray(n['@type'])&&n['@type'].indexOf('Person')>=0)));
        if(!p) return;
        name=clean(p.name||'');
        title=clean(Array.isArray(p.jobTitle)?p.jobTitle[0]:(p.jobTitle||''));
        const wf=Array.isArray(p.worksFor)?p.worksFor[0]:p.worksFor;
        if(wf) company=clean(wf.name||'');
        if(p.address) loc=clean(p.address.addressLocality||p.address.addressCountry||'');
        if(!loc&&p.homeLocation) loc=clean(p.homeLocation.name||(p.homeLocation.address&&p.homeLocation.address.addressLocality)||'');
        about=clean(p.description||'');
      }catch(e){}
    });
  }catch(e){}
  // 1.5) Voyager data blobs — the logged-in SPA embeds its state as JSON inside <code> tags;
  //      on a LOGGED-IN profile this is where name/headline/company/member-id actually live
  //      (the JSON-LD Person schema above is mostly served to logged-out visitors/crawlers,
  //      which is why a logged-in scrape used to find only the h1 name). The member id
  //      (urn:li:fsd_profile:ACoAA…) also lets the CRM recognise this person when they were
  //      captured via Sales Navigator (…/sales/lead/ACwAA… = same id, different type prefix).
  let memberId='';
  try{
    const slug=decodeURIComponent(((window.location.pathname.match(/\/in\/([^\/]+)/)||[])[1]||'')).toLowerCase();
    let prof=null; const positions=[];
    if(slug){
      document.querySelectorAll('code').forEach(c=>{
        const blob=c.textContent||'';
        if(blob.indexOf('publicIdentifier')<0 && blob.indexOf('fsd_profilePosition')<0) return;
        let j=null; try{ j=JSON.parse(blob); }catch(e){ return; }
        ((j&&j.included)||[]).forEach(e=>{
          if(!e) return;
          if(!prof && e.publicIdentifier && String(e.publicIdentifier).toLowerCase()===slug && (e.firstName||e.lastName)) prof=e;
          if(e.title!==undefined && e.companyName!==undefined && /fsd_profilePosition/.test(String(e.entityUrn||''))) positions.push(e);
        });
      });
    }
    if(prof){
      const um=String(prof.entityUrn||'').match(/fsd_profile:(AC[a-zA-Z0-9_-]+)/); if(um) memberId=um[1];
      if(!name) name=clean([prof.firstName,prof.lastName].filter(Boolean).join(' '));
      if(!title) title=clean(prof.headline||'');
      if(!loc) loc=clean(prof.geoLocationName||(prof.geoLocation&&prof.geoLocation.geoLocationName)||'');
      if(!about) about=clean(prof.summary||'');
    }
    if(memberId && positions.length){
      // only positions belonging to THIS profile (their urn embeds the member id)
      const own=positions.filter(p=>String(p.entityUrn||'').indexOf(memberId)>=0);
      const cur=own.find(p=>!(p.dateRange&&p.dateRange.end))||own[0];
      if(cur){ if(!company) company=clean(cur.companyName||''); if(!title) title=clean(cur.title||''); }
    }
  }catch(e){}
  // 1.6) New LinkedIn "SDUI"/flagship profile (2025+): the logged-in page carries NO <code> Voyager
  //       blobs and NO JSON-LD, so 1.5 finds nothing. The viewed member's id (ACoAA…) still lives in
  //       the server-rendered markup — recover it from the whole page HTML so a /in/ visit matches a
  //       CRM row captured under a Sales-Navigator URL (ACwAA… — same id, different 3-char type
  //       prefix; see liIdTail). Anchors, best → weakest, all pointing at THIS profile:
  try{
    const onProfile=/\/(?:in|sales)\//.test(window.location.pathname);
    if(onProfile && !memberId){
      const H=document.documentElement.innerHTML||'';
      const pick=re=>{ const m=H.match(re); return m?m[1]:''; };
      memberId =
        pick(/vieweeProfileId\\?"\s*:\s*\\?"(AC[a-zA-Z0-9_-]{15,})/) ||   // explicit "profile being viewed"
        pick(/profile\.card\.ref(AC[a-zA-Z0-9_-]{15,})Topcard/) ||        // the profile's own top-card component (survives hydration)
        pick(/sales\/(?:people|lead)\/(AC[a-zA-Z0-9_-]{15,})/) ||         // the Sales-Nav URL LinkedIn embeds for this person
        '';
      if(!memberId){ // last resort: the id that dominates the page is the member being viewed
        const freq={}; (H.match(/AC[a-zA-Z0-9_-]{25,}/g)||[]).forEach(id=>{ const b=id.replace(/(?:Topcard|SupportedLocales|_show_\w+)$/,''); freq[b]=(freq[b]||0)+1; });
        let best='',bc=0; Object.keys(freq).forEach(k=>{ if(freq[k]>bc){ bc=freq[k]; best=k; } });
        if(bc>=5) memberId=best;
      }
    }
  }catch(e){}
  // 1.7) New-profile top-card TEXT — read the visible top card in document order so it survives
  //       LinkedIn's obfuscated, ever-changing class names. SEMANTIC, not positional (v3.6): the
  //       hydrated live page can render the topcard as headline → location with NO separate
  //       employer row (which used to shove the location into `company`). So: the location is the
  //       line carrying "Contact info" (or a geo-looking line), the employer is a non-geo line
  //       between headline and location, and a "Role bei/at Company" headline is split when the
  //       page revealed no employer row. Only a fallback: the data paths above win.
  try{
    if((!title||!company||!loc||!name) && /\/in\//.test(window.location.pathname)){
      const rawT=document.title||'';
      const nm=clean(rawT.replace(/^\(\d+\)\s*/,'').split('|')[0].split(' – ')[0].split(' - ')[0]);
      // the page <title> ("Name | LinkedIn") is the most reliable name source on the SDUI page —
      // but only trust it when the title actually carries the LinkedIn marker
      if(!name && nm && nm.length>=2 && nm.length<=80 && /linkedin/i.test(rawT) && !/linkedin|sales navigator/i.test(nm)) name=nm;
      const mainEl=document.querySelector('main');
      const lines=((mainEl?mainEl.innerText:document.body.innerText)||'').split('\n').map(clean).filter(Boolean);
      const CONTACT=/\b(?:contact info|kontaktinfo\w*|contactgegevens)\b/i;
      const GEO=l=>((l.match(/,/g)||[]).length>=2)||/\b(?:area|region|metropol\w*|germany|deutschland|austria|österreich|schweiz|switzerland|netherlands|nederland|belgium|belgië|belgie)\b/i.test(l);
      let i=nm?lines.findIndex(l=>l===nm||l.indexOf(nm)===0):-1; i=(i<0)?0:i+1;
      // Verified on real rendered captures: the employer/school block can sit BEFORE the
      // "Contact info" line (…headline → employer → location · Contact info…) OR AFTER it
      // (…headline → location → Contact info → employer → school → followers). So: read on past
      // "Contact info" and only stop at the followers/connections row; the first non-geo,
      // non-numeric line that isn't the headline is the employer.
      let degree='', hl='', emp='', lc='', seenContact=false;
      const h1t=clean((document.querySelector('main h1')||{innerText:''}).innerText||''); // never read the bare name as a headline
      for(let k=i;k<Math.min(lines.length,i+14);k++){
        let l=lines[k];
        const dm=l.match(/^·?\s*(1st|2nd|3rd|1\.|2\.|3\.)\+?$/i); if(dm){ if(!degree) degree=dm[1]; continue; }
        if(l==='·'||l===nm||(h1t&&l===h1t)||/^[\d.,+]+\+?$/.test(l)) continue;
        if(/^(?:more|mehr|meer|premium|message|connect|follow|nachricht|vernetzen|folgen|bericht|volgen|open to|\(|he\/|she\/|they\/)/i.test(l)) continue;
        if(/\b(?:followers?|connections|kontakte|connecties|verbindingen)\b/i.test(l)) break; // past the topcard
        if(CONTACT.test(l)){ l=clean(l.replace(CONTACT,'').replace(/[·\s]+$/,'').replace(/^[·\s]+/,'')); if(l&&!lc) lc=l; seenContact=true; continue; }
        if(!hl&&!seenContact){ hl=l; continue; }
        if(GEO(l)){ if(!lc) lc=l; continue; }
        if(!emp) emp=clean(l.split(' · ')[0]); // employer row, drop a trailing "· school"
      }
      if(hl){ headNote=hl; if(!title){ title=hl; tHead=true; } }
      if(!company&&emp) company=emp;
      if(!loc&&lc) loc=lc;
      // "Role bei/at Company" headline + no employer row revealed → split it
      if(tHead&&!company){
        const m=title.split(/\s+(?:·|•|\||–|\bat\b|\bbei\b|\bbij\b|@)\s+/i);
        if(m.length>1&&clean(m[m.length-1]).length<=60){ company=clean(m[m.length-1]); title=clean(m[0]); }
      }
      // network signals for the note (safe patterns, trilingual labels)
      const all=lines.join(' ');
      const conn=(all.match(/([\d.,]+\+?)\s*(?:connections|Kontakte|connecties|verbindingen)/i)||[])[1]||'';
      network=[degree?('🤝 '+degree):'', conn?('👥 '+conn+' connections'):''].filter(Boolean).join(' • ');
    }
  }catch(e){}
  // helper for the scrolled-in cards: find a section by its heading text (EN/DE/NL UIs)
  function liSec(re){
    let s=null;
    document.querySelectorAll('main h2,main h3,main [role="heading"]').forEach(h=>{
      if(s) return; const t=clean(h.innerText).toLowerCase();
      if(re.test(t)) s=h.closest('section')||h.parentElement;
    });
    return s;
  }
  // 1.8) Experience card — only in the DOM once the SDR scrolled it into view (hence the
  //       "scroll to Experience, then re-scan" hint). Parsed text-based against the REAL hydrated
  //       layout (verified on a saved scrolled page), which comes in TWO shapes:
  //         grouped — company header / "4 yrs 1 mo" total-duration / roles beneath it
  //         flat    — title / "Company · Type" / date-range
  //       A pure-duration line marks the line before it as a company-group header; a " · " line
  //       carries the company of a flat entry; type/geo/skills lines are dropped. The CURRENT
  //       position beats a slogan-headline for title/company; the career summary goes into the
  //       notes (💼 …) so re-opening the popup after scrolling yields MORE data, which
  //       autoCrmCheck then merges into an already-stored lead's notes.
  let career='', edu='', langsNote='', cert='';
  try{
    let sec=document.getElementById('experience');
    sec=sec?(sec.closest('section')||sec.parentElement):liSec(/^(?:experience|berufserfahrung|ervaring|werdegang)\b/);
    if(sec){
      const DATE=/\b(?:19|20)\d{2}\b|\b(?:present|heute|heden|today)\b/i;
      const DUR=/^\d+\s*(?:yrs?|mos?|jahre?|jahr|monate?|maanden?|jaar|mnd)\b[\s\S]{0,20}$/i;
      const TYPE=/^(?:full-?time|part-?time|vollzeit|teilzeit|freelance|self-?employed|selbstst\w+|permanent|festanstellung|contract|internship|praktikum|werkstudent\w*|work study|hybrid|remote|on-?site|vor ort|befristet|zzp)$/i;
      const NOISE=/^(?:experience|berufserfahrung|ervaring|werdegang|show all\b.*|alle\b.*anzeigen.*|toon alle\b.*|…\s*(?:more|mehr|meer)?|helpful)$/i;
      const SKILLS=/(?:\band \+\d+ skills?$)|(?:\+\d+\s*(?:skills|kenntnisse|vaardigheden))|(?:^skills?:)|(?:^kenntnisse:)|(?:^vaardigheden:)/i;
      const GEO2=l=>((l.match(/,/g)||[]).length>=2)||/\b(?:area|region|metropol\w*)\b/i.test(l);
      const ls=(sec.innerText||'').split('\n').map(clean).filter(Boolean);
      const entries=[]; let pend=[], groupCo='';
      for(const l of ls){
        if(entries.length>=5) break;
        if(NOISE.test(l)||SKILLS.test(l)||TYPE.test(l)||l.length>90) continue;
        if(DATE.test(l)){
          if(pend.length){
            let t='', c='';
            const ci=pend.findIndex(p=>p.indexOf(' · ')>=0);      // flat: "Company · Type" line
            // Stray lines (a bare city, a leftover skill chip) can precede the real title, so the
            // title is the line DIRECTLY next to its anchor: just above the "Company · Type" line,
            // or the last line before the date (verified against real profiles).
            if(ci>=0){ c=clean(pend[ci].split(' · ')[0]); t=(ci>0?pend[ci-1]:pend[ci+1])||''; groupCo=''; }
            else if(groupCo){ t=pend[pend.length-1]; c=groupCo; } // role inside a company group
            else if(pend.length>=2){ t=pend[pend.length-2]; c=pend[pend.length-1]; }
            else { t=pend[0]; c=''; }
            if(t) entries.push({t:t, c:c, d:clean(l.split('·')[0])});
          }
          pend=[]; continue;
        }
        // group-header duration: pure ("4 yrs 1 mo") OR type-prefixed ("Full-time · 12 yrs 5 mos")
        const durCore=clean(l.replace(/^[^·]{2,24}·\s*/,''));
        if(DUR.test(l)||DUR.test(durCore)){ if(pend.length) groupCo=pend[pend.length-1]; pend=[]; continue; }
        if(GEO2(l)) continue;
        pend.push(l);
      }
      if(entries.length){
        const curE=entries.find(e=>/present|heute|heden|today/i.test(e.d||''))||entries[0];
        if(curE&&curE.t&&curE.t.length<=60&&(tHead||!title)) title=clean(curE.t);
        if(curE&&curE.c&&curE.c.length<=70&&(tHead||!company)) company=clean(curE.c);
        career='💼 '+entries.map(e=>e.t+(e.c?' @ '+e.c:'')+(e.d?' ('+e.d+')':'')).join(' | ');
        if(career.length>420) career=career.slice(0,417)+'…';
      }
    }
  }catch(e){}
  // 1.9) More scrolled-in cards → note pieces the SDR (and the AI message drafts) can use:
  //       About (— …), Education (🎓), Languages (🌐 — also sharpens the outreach-language guess),
  //       first certification (📜). All best-effort, headings matched in EN/DE/NL.
  try{
    if(!about){
      const sa=liSec(/^(?:about|info|over)$/);
      if(sa){
        const t=(sa.innerText||'').split('\n').map(clean)
          .filter(l=>l&&!/^(?:about|info|over)$/i.test(l)&&!/^…?\s*(?:more|mehr|meer|see more|mehr anzeigen|meer weergeven)$/i.test(l)).join(' ');
        about=clean(t).slice(0,500);
      }
    }
  }catch(e){}
  try{
    const se=liSec(/^(?:education|ausbildung|opleiding)\b/);
    if(se){
      const YR=/\b(?:19|20)\d{2}\b/;
      const ls=(se.innerText||'').split('\n').map(clean).filter(Boolean)
        .filter(l=>!/^(?:education|ausbildung|opleiding)\b/i.test(l)&&!/^(?:show all|alle .*anzeigen|toon alle)/i.test(l));
      const items=[]; let p=[];
      for(const l of ls){
        if(items.length>=2) break;
        if(YR.test(l)){ if(p.length) items.push((p[1]?p[1]+' · ':'')+p[0]+' ('+l+')'); p=[]; continue; }
        if(l.length<=90) p.push(l);
      }
      if(items.length) edu='🎓 '+items.join(' | ');
    }
  }catch(e){}
  try{
    const sl=liSec(/^(?:languages|sprachen|talen)\b/);
    if(sl){
      const PROF=/proficiency|native|bilingual|muttersprache|moedertaal|fließend|fliessend|professional|elementary|limited|working|grundkenntnisse|vloeiend/i;
      const ls=(sl.innerText||'').split('\n').map(clean).filter(Boolean)
        .filter(l=>!/^(?:languages|sprachen|talen)\b/i.test(l)&&!/^(?:show all|alle .*anzeigen|toon alle)/i.test(l));
      const out=[];
      for(const l of ls){
        if(PROF.test(l)){ if(out.length&&/native|bilingual|muttersprache|moedertaal/i.test(l)) out[out.length-1]+=' (native)'; }
        else if(l.length<=30) out.push(l);
      }
      if(out.length) langsNote='🌐 '+out.slice(0,4).join(', ');
    }
  }catch(e){}
  try{
    const sc2=liSec(/^(?:licenses|bescheinigungen|zertifi|licenties)/);
    if(sc2){
      const ls=(sc2.innerText||'').split('\n').map(clean).filter(Boolean)
        .filter(l=>!/^(?:licenses|bescheinigungen|zertifi|licenties)/i.test(l)&&!/^(?:issued|ausgestellt|uitgegeven)/i.test(l)&&!/^(?:show all|alle .*anzeigen|toon alle)/i.test(l));
      if(ls[0]) cert='📜 '+ls[0].slice(0,80);
    }
  }catch(e){}
  // 2) Sales-Nav person-name attribute first (unambiguous when present), then the top-card h1
  if(!name) name=txt('[data-anonymize="person-name"]')||txt('main h1')||txt('h1');
  if(!title) title=txt('div.text-body-medium')||txt('[data-generated-suggestion-target] .text-body-medium');
  if(!company){
    const exp=document.querySelector('[aria-label*="Current company"], button[aria-label*="Current company"]');
    if(exp) company=clean(exp.innerText);
  }
  if(!company){ const li=document.querySelector('section.pv-profile-section .pv-entity__secondary-title, .pvs-entity__caption-wrapper'); if(li) company=clean(li.innerText); }
  if(!company){
    // experience section, first entry — only loaded once the user scrolled it into view
    const exp=document.getElementById('experience');
    const sec=exp&&(exp.closest('section')||exp.parentElement);
    const item=sec&&sec.querySelector('li');
    if(item){
      const sp=item.querySelector('.t-14.t-normal span[aria-hidden="true"]');
      if(sp) company=clean((sp.innerText||'').split('·')[0]);
      if(!title){ const b=item.querySelector('.t-bold span[aria-hidden="true"]'); if(b) title=clean(b.innerText); }
    }
  }
  if(!loc) loc=txt('.pv-text-details__left-panel .text-body-small.inline')||txt('.pv-text-details__left-panel .text-body-small')||txt('.text-body-small.inline.t-black--light.break-words');
  if(!about) about=txt('.inline-show-more-text span[aria-hidden="true"]')||txt('.pv-shared-text-with-see-more span[aria-hidden="true"]');
  // 3) Sales Navigator profile fields
  if(!title) title=txt('[data-anonymize="title"]')||txt('[data-anonymize="headline"]');
  if(!company) company=txt('[data-anonymize="company-name"]');
  if(!loc) loc=txt('[data-anonymize="location"]');
  // 4) Last resort for the name: og:title / document.title — "(2) Jane Doe | LinkedIn"
  if(!name){
    const og=document.querySelector('meta[property="og:title"]');
    let s=clean(((og&&og.getAttribute('content'))||document.title||'').replace(/^\(\d+\)\s*/,''));
    s=clean(s.split('|')[0].split(' – ')[0].split(' - ')[0]);
    if(s&&s.length>=2&&s.length<=80&&!/linkedin|sales navigator/i.test(s)) name=s;
  }
  // clean a trailing company off the headline if present
  if(title&&company&&title.toLowerCase().endsWith(company.toLowerCase())){
    title=clean(title.slice(0,title.length-company.length).replace(/(?:\bat\b|\bbei\b|\bbij\b|[•·\-–|,])\s*$/i,''));
  }
  // Language guess: geography (countries + cities) + legal forms + a stopword score over the
  // profile text itself — so a profile *written* in German counts as German even when the
  // person's LinkedIn UI/location is set to English. ASCII-fold umlauts first (JS \b limitation).
  const fold=t=>(' '+(t||'').toLowerCase()+' ').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[ëéè]/g,'e').replace(/ï/g,'i');
  const s=fold(loc+' '+title+' '+company+' '+about+' '+headNote+' '+career+' '+edu);
  let de=0, nlc=0;
  if(/\b(germany|deutschland|austria|oesterreich|switzerland|schweiz|berlin|muenchen|munich|hamburg|frankfurt|koeln|cologne|stuttgart|duesseldorf|leipzig|dresden|hannover|nuernberg|bremen|dortmund|essen|bonn|mannheim|wien|vienna|graz|linz|salzburg|zuerich|zurich|basel|bern)\b/.test(s)) de+=3;
  if(/\b(netherlands|nederland|holland|belgium|belgie|amsterdam|rotterdam|utrecht|eindhoven|den haag|the hague|groningen|tilburg|breda|nijmegen|haarlem|arnhem|maastricht|leiden|zwolle|delft|antwerpen|antwerp|gent|ghent|brugge|leuven|hasselt|brussel|brussels)\b/.test(s)) nlc+=3;
  if(/\bgmbh\b/.test(s)) de+=2;
  if(/\bb\.v\.|\bbv\b/.test(s)) nlc+=2;
  de+=(s.match(/\b(und|der|das|ist|mit|fuer|bei|wir|nicht|eine|auch|auf|aus|werden|jahre|erfahrung|unternehmen|bereich|leiter|vertrieb|mitarbeiter|kunden|ueber|mehr|seit)\b/g)||[]).length;
  nlc+=(s.match(/\b(en|het|van|voor|bij|wij|niet|een|ook|op|uit|worden|jaar|ervaring|bedrijf|medewerkers|verkoop|klanten|sinds|naar|onze|nieuwe|graag)\b/g)||[]).length;
  // a scraped Languages card naming the NATIVE language is the strongest signal of all
  if(/(?:deutsch|german)[^,•|]*\(native\)/i.test(langsNote)) de+=3;
  if(/(?:nederlands|dutch)[^,•|]*\(native\)/i.test(langsNote)) nlc+=3;
  const guessedLang=(de>=2&&de>nlc)?'German':((nlc>=2&&nlc>de)?'Dutch':'English');
  // On a Sales-Navigator page, also try to pick up the person's public /in/ profile URL —
  // one more key for the same-person matching (Sales-Nav row ↔ normal-profile visit).
  let publicUrl='';
  try{
    if(/linkedin\.com\/sales\//.test(window.location.href)){
      const a=document.querySelector('a[href*="linkedin.com/in/"]');
      if(a) publicUrl=(a.href||'').split('?')[0];
      if(!publicUrl){
        const m=(document.documentElement.innerHTML||'').match(/"flagshipProfileUrl":"(https:[^"]*?linkedin\.com\/in\/[^"]+?)"/);
        if(m) publicUrl=m[1].replace(/\\u002[fF]/g,'/').split('?')[0];
      }
    }
  }catch(e){}
  const notes=[ loc?('📍 '+loc):'', '🗣 '+guessedLang, network||'', title||'', company?('🏢 '+company):'',
    (headNote&&headNote!==title)?('💬 '+headNote):'', career||'', edu||'', langsNote||'', cert||'',
    about?('— '+about.slice(0,280)):'' ].filter(Boolean).join(' • ');
  return { name, title, newCompany:company, oldCompany:'', size:'', linkedinUrl: window.location.href.split('?')[0], notes, memberId, publicUrl };
}

// ── campaign field (= the lead's `tags`, relabelled "Campaign" in the UI) ────
// One required campaign per lead; for a scrape it applies to the whole batch. Existing
// campaigns are suggested (datalist + quick chips); you can also type a brand-new one.
function campaignFieldHTML(){
  return '<label style="font-size:11px;color:#667085;font-weight:600;display:block;margin-bottom:3px">'+L('campaignLabel')+' <span style="color:#b42318">*</span></label>'+
    '<input id="ext-campaign" list="ext-campaign-list" autocomplete="off" placeholder="'+L('campaignPick')+'" style="width:100%;height:32px;border:1px solid #d0d5dd;border-radius:8px;font:inherit;font-size:12px;padding:0 8px;background:#fff;box-sizing:border-box">'+
    '<datalist id="ext-campaign-list"></datalist>'+
    '<div id="ext-campaign-suggest" style="display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 2px"></div>'+
    '<div style="font-size:10px;color:#98a2b3;margin-bottom:6px">'+L('campaignNew')+'</div>';
}
async function loadCampaigns(){
  if(extCampaigns) return extCampaigns;
  const key=effectiveKey(); if(!key) return [];
  try{
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
    if(!resp.ok) return [];
    const data=await resp.json(); const arr=(data&&Array.isArray(data.leads))?data.leads:[];
    const set=new Set();
    arr.forEach(l=>{ if(l.status==='deleted') return; safeArr(l.tags).forEach(tg=>{ if(tg) set.add(String(tg)); }); });
    extCampaigns=Array.from(set).sort((a,b)=>a.localeCompare(b));
    return extCampaigns;
  }catch(e){ return []; }
}
async function populateCampaigns(){
  const inp=document.getElementById('ext-campaign'); if(!inp) return;
  const list=await loadCampaigns();
  const dl=document.getElementById('ext-campaign-list'); if(dl) dl.innerHTML=list.map(c=>'<option value="'+esc(c)+'"></option>').join('');
  const sug=document.getElementById('ext-campaign-suggest');
  if(sug){ sug.innerHTML=''; list.slice(0,8).forEach(c=>{ const b=document.createElement('span'); b.textContent=c;
    b.style.cssText='font-size:11px;padding:2px 9px;border-radius:999px;background:rgba(0,97,194,.10);color:#004e9b;font-weight:600;cursor:pointer';
    b.addEventListener('click',()=>{ inp.value=c; syncSendEnabled(); }); sug.appendChild(b); }); }
  inp.addEventListener('input',syncSendEnabled); syncSendEnabled();
}
// the send / add button stays disabled until a campaign has been chosen/typed
function syncSendEnabled(){ const inp=document.getElementById('ext-campaign'); const btn=document.getElementById('send-btn'); if(btn) btn.disabled=!(inp&&inp.value.trim()); }
function selectedCampaign(){ const inp=document.getElementById('ext-campaign'); return (inp&&inp.value||'').trim(); }
// profile "✓ Add to CRM": import this one profile under the chosen campaign, then RE-CHECK the
// CRM — that refreshes the badge to "Already in the CRM (status · campaign)" and switches the
// panel to the compose tools (the badge used to stay grey after adding).
async function addProfileToCrm(){
  const ok=await sendToN8n(true);
  if(ok){ extCampaigns=null; autoCrmCheck(scrapedLeads&&scrapedLeads[0]); }
}

// ── results + send ────────────────────────────────────────────────────────────
function renderResults(leads,isProfile){
  const el=document.getElementById('results'); el.innerHTML='<hr class="divider">';
  if(!isProfile){
    // one campaign for the whole scraped batch (required) — chosen before sending
    const cw=document.createElement('div'); cw.id='ext-campaign-wrap'; cw.innerHTML=campaignFieldHTML(); el.appendChild(cw);
    const sendBtn=document.createElement('button'); sendBtn.className='btn btn-green'; sendBtn.id='send-btn'; sendBtn.disabled=true;
    sendBtn.textContent=L('sendBtn',{n:leads.length}); sendBtn.addEventListener('click',()=>sendToN8n(false)); el.appendChild(sendBtn);
  }
  const hdr=document.createElement('div'); hdr.className='results-header';
  hdr.textContent=leads.length+L('preview')+' — '+(effectiveEnv()==='test'?'🧪 Test':'⚙️ Prod'); el.appendChild(hdr);
  leads.slice(0,3).forEach(l=>{ const c=document.createElement('div'); c.className='lead-card';
    c.innerHTML='<div class="lc-name">'+esc(l.name)+'</div><div class="lc-sub">'+esc(l.title||'—')+'</div><div class="lc-company">'+esc(l.newCompany||'')+'</div>'; el.appendChild(c); });
  if(leads.length>3){ const m=document.createElement('div'); m.className='more'; m.textContent='+'+(leads.length-3); el.appendChild(m); }
  if(isProfile){
    const lead=scrapedLeads&&scrapedLeads[0];
    const guessed=extGuessLang(lead);
    // Little data scraped (no title/company)? Amber warning. Basics fine but the career (💼) not
    // read yet (Experience card only enters the DOM once scrolled)? Softer tip — scroll, reopen,
    // the re-scan reads it and (for a stored lead) autoCrmCheck merges it into the notes.
    const noBasics=!lead || !lead.title || !lead.newCompany;
    const noCareer=lead && String(lead.notes||'').indexOf('💼')<0;
    if(noBasics || noCareer){
      const inc=document.createElement('div'); inc.id='scrape-incomplete';
      inc.style.cssText=noBasics
        ?'font-size:11px;line-height:1.5;color:#6b3c00;background:#fef0d8;border:1px solid #f5c26b;border-radius:8px;padding:8px 10px;margin:8px 0'
        :'font-size:11px;line-height:1.5;color:#475467;background:#f2f4f7;border:1px solid #d0d5dd;border-radius:8px;padding:8px 10px;margin:8px 0';
      inc.textContent=L(noBasics?'scrapeIncomplete':'scrapeMore');
      const rb=document.createElement('button'); rb.id='rescan-btn'; rb.textContent=L('rescanBtn');
      rb.style.cssText='display:block;margin-top:6px;font:inherit;font-size:11px;font-weight:600;padding:3px 10px;border-radius:7px;border:1px solid #f5c26b;background:#fff;color:#6b3c00;cursor:pointer';
      rb.addEventListener('click',autoProfileChecks);
      inc.appendChild(rb);
      el.appendChild(inc);
    }
    // campaign + "Add to CRM" (required) — hidden by reflectProfileCrm() once the lead is in the CRM
    const addWrap=document.createElement('div'); addWrap.id='crm-add-wrap'; addWrap.style.marginTop='8px';
    addWrap.innerHTML=campaignFieldHTML()+'<button class="btn btn-primary" id="send-btn" disabled>'+L('addToCrm')+'</button>';
    el.appendChild(addWrap);
    document.getElementById('send-btn').addEventListener('click',addProfileToCrm);
    const wrap=document.createElement('div'); wrap.id='ext-compose'; wrap.style.marginTop='8px';
    wrap.innerHTML=
      '<div style="font-size:11px;color:#667085;margin-bottom:6px;display:flex;align-items:center;gap:4px">🗣 <select id="ext-lang" style="height:26px;font:inherit;font-size:11px;border:1px solid #d0d5dd;border-radius:7px;padding:0 4px;background:#fff;color:#111"><option value="auto">'+L('langAuto')+' · '+guessed+'</option><option value="English">English</option><option value="German">Deutsch</option><option value="Dutch">Nederlands</option></select></div>'+
      '<select id="tpl-select" style="width:100%;margin-bottom:6px;height:30px;border:1px solid #d0d5dd;border-radius:8px;font:inherit;font-size:12px;padding:0 6px;background:#fff"><option value="">'+L('tplNone')+'</option></select>'+
      '<textarea id="ext-msg" placeholder="'+L('msgPlaceholder')+'" style="width:100%;min-height:96px;font:inherit;font-size:12px;border:1px solid #d0d5dd;border-radius:8px;padding:8px;line-height:1.5;box-sizing:border-box"></textarea>'+
      '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">'+
        '<button class="btn" id="opener-btn">'+L('openerBtn')+'</button>'+
        '<button class="btn" id="personalize-btn">'+L('personalizeBtn')+'</button>'+
        '<button class="btn" id="copy-msg-btn">'+L('openerCopy')+'</button>'+
      '</div>'+
      '<div id="ext-actions-hint" style="font-size:10px;color:#98a2b3;margin:8px 0 2px">'+L('actionsNeedCrm')+'</div>'+
      '<div style="display:flex;gap:6px;margin-top:4px;flex-wrap:wrap">'+
        '<button class="btn btn-green" id="msg-sent-btn" disabled>'+L('markSentBtn')+'</button>'+
        '<button class="btn" id="pd-add-btn" disabled>'+L('pdAddBtn')+'</button>'+
      '</div>';
    el.appendChild(wrap);
    document.getElementById('opener-btn').addEventListener('click',genOpener);
    document.getElementById('personalize-btn').addEventListener('click',personalizeExt);
    document.getElementById('copy-msg-btn').addEventListener('click',copyExt);
    document.getElementById('msg-sent-btn').addEventListener('click',markSentExt);
    document.getElementById('pd-add-btn').addEventListener('click',pipedriveAddExt);
    document.getElementById('tpl-select').addEventListener('change',onTplSelect);
    loadExtTemplates();
    reflectProfileCrm();
  }
  populateCampaigns();
}
// ── prospect language guess from the scraped notes/location/company/title ──
// Geography + legal forms + stopword score over the profile text, so a German-written profile
// counts as German even when its location/UI is English; the stored "🗣 <lang>" hint from the
// scraper is only the fallback when the text itself is inconclusive.
function detectLangFrom(text){
  const s=(' '+String(text||'').toLowerCase()+' ').replace(/ä/g,'ae').replace(/ö/g,'oe').replace(/ü/g,'ue').replace(/ß/g,'ss').replace(/[ëéè]/g,'e').replace(/ï/g,'i');
  let de=0, nl=0;
  if(/\b(germany|deutschland|austria|oesterreich|switzerland|schweiz|berlin|muenchen|munich|hamburg|frankfurt|koeln|cologne|stuttgart|duesseldorf|leipzig|dresden|hannover|nuernberg|bremen|dortmund|essen|bonn|mannheim|wien|vienna|graz|linz|salzburg|zuerich|zurich|basel|bern)\b/.test(s)) de+=3;
  if(/\b(netherlands|nederland|holland|belgium|belgie|amsterdam|rotterdam|utrecht|eindhoven|den haag|the hague|groningen|tilburg|breda|nijmegen|haarlem|arnhem|maastricht|leiden|zwolle|delft|antwerpen|antwerp|gent|ghent|brugge|leuven|hasselt|brussel|brussels)\b/.test(s)) nl+=3;
  if(/\bgmbh\b/.test(s)) de+=2;
  if(/\bb\.v\.|\bbv\b/.test(s)) nl+=2;
  de+=(s.match(/\b(und|der|das|ist|mit|fuer|bei|wir|nicht|eine|auch|auf|aus|werden|jahre|erfahrung|unternehmen|bereich|leiter|vertrieb|mitarbeiter|kunden|ueber|mehr|seit)\b/g)||[]).length;
  nl+=(s.match(/\b(en|het|van|voor|bij|wij|niet|een|ook|op|uit|worden|jaar|ervaring|bedrijf|medewerkers|verkoop|klanten|sinds|naar|onze|nieuwe|graag)\b/g)||[]).length;
  if(de>=2&&de>nl) return 'German';
  if(nl>=2&&nl>de) return 'Dutch';
  const hint=s.match(/🗣\s*(german|deutsch|dutch|nederlands|english|engels|englisch)/);
  if(hint) return (hint[1]==='german'||hint[1]==='deutsch')?'German':(hint[1]==='dutch'||hint[1]==='nederlands')?'Dutch':'English';
  return '';
}
function extGuessLang(lead){
  const s=((lead&&lead.notes)||'')+' '+((lead&&lead.newCompany)||'')+' '+((lead&&lead.title)||'');
  return detectLangFrom(s) || (EXT_I18N[cfg.lang]&&EXT_I18N[cfg.lang]._name) || 'English';
}
// language actually used = the override dropdown, or the guess when set to "auto"
function extLang(lead){ const sel=document.getElementById('ext-lang'); if(sel && sel.value && sel.value!=='auto') return sel.value; return extGuessLang(lead); }
// ── templates from the DB (list-templates) so the SDR can pick one in the popup ──
let extTemplates=[];
async function loadExtTemplates(){
  if(!effectiveKey()) return;
  try{
    const key=effectiveKey();
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list-templates',apiKey:key}) });
    if(!resp.ok) return;
    const info=await resp.json();
    extTemplates=(info&&Array.isArray(info.templates))?info.templates.filter(function(tp){ return tp&&!tp.deleted; }):[];
    const sel=document.getElementById('tpl-select'); if(!sel) return;
    extTemplates.forEach(function(tp){ const o=document.createElement('option'); o.value=tp.id; o.textContent=tp.name||'—'; sel.appendChild(o); });
  }catch(e){}
}
function fillExtPlaceholders(body,lead){
  const first=(((lead&&lead.name)||'').trim().split(/\s+/)[0])||'';
  return (body||'').replace(/\{voornaam\}/g,first).replace(/\{bedrijf\}/g,(lead&&(lead.newCompany||lead.oldCompany))||'');
}
function onTplSelect(){
  const sel=document.getElementById('tpl-select'); const lead=scrapedLeads&&scrapedLeads[0]; if(!sel||!lead) return;
  const tp=extTemplates.find(function(t){ return t.id===sel.value; });
  const box=document.getElementById('ext-msg'); if(tp&&box) box.value=fillExtPlaceholders(tp.body,lead);
}
function copyExt(){
  const box=document.getElementById('ext-msg'); if(!box) return; box.select(); try{ document.execCommand('copy'); }catch(e){}
  const b=document.getElementById('copy-msg-btn'); if(b){ b.textContent=L('openerCopied'); setTimeout(function(){ b.textContent=L('openerCopy'); },1500); }
}
// ── find the imported lead (by row id from the CRM check, else by liKeysOf match), mutate it,
//    write it back (list -> sync; no n8n change) ──
async function syncLeadUpdate(scraped, mutateFn){
  const key=effectiveKey();
  const target=liKeysOf(scraped);
  const listResp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
  if(listResp.status===401||listResp.status===403) return {auth:true};
  if(!listResp.ok) throw new Error('HTTP '+listResp.status);
  const data=await listResp.json();
  const arr=(data&&Array.isArray(data.leads))?data.leads:[];
  const lead=(profileCrmLead&&profileCrmLead.id?arr.find(function(l){ return l.id===profileCrmLead.id; }):null)
    || arr.find(function(l){ return l.status!=='deleted'&&liSame(target, liKeysOf(l)); });
  if(!lead) return {notFound:true};
  mutateFn(lead);
  const syncResp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'sync',apiKey:key,leads:[lead]}) });
  if(!syncResp.ok) throw new Error('HTTP '+syncResp.status);
  return {ok:true, lead:lead};
}
// ── copy the message AND log it onto the lead (status -> messaged) ──
// The button says "Copy message & mark as sent", so it does exactly that: clipboard first,
// then the list->sync write. The SDR pastes it into LinkedIn right after.
async function markSentExt(){
  const lead=scrapedLeads&&scrapedLeads[0]; if(!lead) return;
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const box=document.getElementById('ext-msg'); const text=((box&&box.value)||'').trim();
  if(!text){ setStatus('err',L('markSentNeed')); return; }
  try{ await navigator.clipboard.writeText(text); }catch(e){ try{ box.select(); document.execCommand('copy'); }catch(e2){} }
  const btn=document.getElementById('msg-sent-btn'); if(btn){ btn.disabled=true; btn.textContent=L('sending'); }
  try{
    const r=await syncLeadUpdate(lead, function(l){
      if(!Array.isArray(l.messagesSent)) l.messagesSent=[];
      l.messagesSent.push({templateId:'', text:text, sentAt:new Date().toISOString()});
      if(!l.status || l.status==='new' || l.status==='benaderen') l.status='messaged';
    });
    if(r.auth){ setStatus('err',L('invalidKey')); }
    else if(r.notFound){ setStatus('err',L('leadNotFound')); }
    else { setStatus('ok',L('markSentDone')); if(btn) btn.textContent=L('markSentDoneShort'); }
  }catch(e){ setStatus('err','❌ '+e.message); }
  finally{ if(btn){ btn.disabled=false; if(btn.textContent===L('sending')) btn.textContent=L('markSentBtn'); } }
}
// ── create this person in Pipedrive (org + person + deal + note) and flag the lead ──
async function pipedriveAddExt(){
  const lead=scrapedLeads&&scrapedLeads[0]; if(!lead) return;
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('pd-add-btn'); if(btn){ btn.disabled=true; btn.textContent=L('pdAdding'); }
  const key=effectiveKey();
  const leadType=/interim|freelance|freelancer|zzp|\bai\b/i.test(lead.title||'')?'partner':'direct';
  try{
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'pipedrive-add',apiKey:key,lead:{name:lead.name,title:lead.title||'',oldCompany:lead.oldCompany||'',newCompany:lead.newCompany||'',url:lead.linkedinUrl||'',leadType:leadType,notes:lead.notes||''}}) });
    if(resp.status===401||resp.status===403){ setStatus('err',L('invalidKey')); if(btn){ btn.disabled=false; btn.textContent=L('pdAddBtn'); } return; }
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    const info=await resp.json(); const dealId=(info&&info.dealId)?String(info.dealId):'yes';
    setStatus('ok',L('pdAdded')); if(btn) btn.textContent=L('pdAddedShort');
    // flag the lead in the sheet so the CRM shows "In Pipedrive" and won't create a duplicate
    try{ await syncLeadUpdate(lead, function(l){ l.pipedrive=dealId; l.status='in-pipedrive'; }); }catch(e){}
    if(btn) btn.disabled=false;
  }catch(e){ setStatus('err','❌ '+e.message); if(btn){ btn.disabled=false; btn.textContent=L('pdAddBtn'); } }
}
// ── AI: draft a from-scratch opener (ai-message), in the prospect's guessed language ──
async function genOpener(){
  const lead=scrapedLeads&&scrapedLeads[0]; if(!lead) return;
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('opener-btn'); if(btn){ btn.disabled=true; btn.textContent=L('openerBusy'); }
  const key=effectiveKey();
  const langName=extLang(lead);
  const system='You are a sales assistant for HoorayHR (HR software for SMBs). Write a short, warm, personal LinkedIn outreach message to someone who recently changed jobs. Be human, never salesy, max 4 sentences. Reply ONLY with the message text.';
  // v3.7: hand the scraped profile context (career, about, education, languages …) to the AI so
  // the opener can reference something real — one or two details, woven in naturally.
  const ctx=((lead&&lead.notes)||'').slice(0,600);
  const prompt='Write a LinkedIn opener for '+lead.name+(lead.title?(', '+lead.title):'')+(lead.newCompany?(' at '+lead.newCompany):'')+'. Congratulate them on the new role and gently open a conversation about HR software.'+(ctx?('\nProfile context from LinkedIn (pick 1-2 specific details and weave them in naturally — never list them): '+ctx):'')+'\nReply ONLY with the message text, in this language: '+langName+'.';
  try {
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'ai-message',apiKey:key,system:system,prompt:prompt,lead:lead}) });
    if(resp.status===401||resp.status===403){ setStatus('err',L('invalidKey')); return; }
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    const info=await resp.json(); const box=document.getElementById('ext-msg'); if(box&&info&&info.text) box.value=String(info.text).trim();
  } catch(e){ setStatus('err','❌ '+e.message); }
  finally { if(btn){ btn.disabled=false; btn.textContent=L('openerBtn'); } }
}
// ── AI: lightly personalise the selected template / current draft, staying close to it ──
async function personalizeExt(){
  const lead=scrapedLeads&&scrapedLeads[0]; if(!lead) return;
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const box=document.getElementById('ext-msg'); const cur=((box&&box.value)||'').trim();
  const sel=document.getElementById('tpl-select'); const tp=sel?extTemplates.find(function(t){ return t.id===sel.value; }):null;
  const langName=extLang(lead);
  // v3.7: the scraped profile context tells the AI WHICH small detail to adapt
  const pctx=((lead&&lead.notes)||'').slice(0,600);
  const ctxLine=pctx?('\nProfile context from LinkedIn (source for the adapted detail): '+pctx):'';
  let prompt;
  if(cur){
    prompt='Here is a draft message:\n"""'+cur+'"""\n\nPersonalise it only LIGHTLY for '+lead.name+': keep its structure, tone, length and almost all of its wording; just adapt one or two small details so it fits this person. Do NOT rewrite it from scratch.'+ctxLine+'\nReply ONLY with the message text, in this language: '+langName+'.';
  } else if(tp){
    prompt='Here is a message template for '+lead.name+':\n"""'+fillExtPlaceholders(tp.body,lead)+'"""\n\nPersonalise it only LIGHTLY: keep its structure and almost all wording, adapt a small detail.'+ctxLine+'\nReply ONLY with the message text, in this language: '+langName+'.';
  } else { setStatus('err',L('personalizeNeed')); return; }
  const btn=document.getElementById('personalize-btn'); if(btn){ btn.disabled=true; btn.textContent=L('openerBusy'); }
  const key=effectiveKey();
  const system='You are a sales assistant for HoorayHR (HR software for SMBs). Keep outreach short, warm and human. Reply ONLY with the message text.';
  try {
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'ai-message',apiKey:key,system:system,prompt:prompt,lead:lead}) });
    if(resp.status===401||resp.status===403){ setStatus('err',L('invalidKey')); return; }
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    const info=await resp.json(); if(box&&info&&info.text) box.value=String(info.text).trim();
  } catch(e){ setStatus('err','❌ '+e.message); }
  finally { if(btn){ btn.disabled=false; btn.textContent=L('personalizeBtn'); } }
}
// ── Pipedrive pre-check on scrape (no n8n change — reuses the pipedrive-check action) ─────────
// One lead: returns the pipedrive-check response, or null on any failure (a failure counts as "not found").
async function checkLeadInPd(lead){
  const key=effectiveKey();
  try{
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'pipedrive-check',apiKey:key,lead:{name:lead.name||'',newCompany:lead.newCompany||'',url:lead.linkedinUrl||lead.url||''}}) });
    if(!resp.ok) return null;
    return await resp.json();
  }catch(e){ return null; }
}
// Many leads, limited concurrency. Tags each lead with _pdPerson / _pdOrg. onProgress(done,total).
async function checkLeadsInPd(leads, onProgress){
  let idx=0, done=0; const limit=Math.min(4, leads.length||1);
  async function worker(){
    while(idx<leads.length){
      const l=leads[idx++]; const info=await checkLeadInPd(l);
      l._pdPerson=!!(info&&info.personExists); l._pdOrg=!!(info&&info.orgExists);
      done++; if(onProgress) onProgress(done, leads.length);
    }
  }
  const pool=[]; for(let k=0;k<limit;k++) pool.push(worker());
  await Promise.all(pool);
}
// After import: move the Pipedrive-matched leads to status "in-pipedrive" in the sheet
// (list -> match via liKeysOf/liSame -> sync). `import` can't set status (it forces "new"), but
// `sync` honours it. Returns how many rows were updated. No n8n change — reuses list + sync.
async function markLeadsInPipedrive(matched){
  if(!matched.length) return 0;
  const key=effectiveKey();
  const keySets=matched.map(function(l){ return liKeysOf(l); });
  const lr=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
  if(!lr.ok) return 0;
  const data=await lr.json(); const arr=(data&&Array.isArray(data.leads))?data.leads:[];
  const toSync=[];
  arr.forEach(function(l){ const rk=liKeysOf(l); if(keySets.some(function(ks){ return liSame(ks,rk); })){ l.status='in-pipedrive'; if(!l.pipedrive) l.pipedrive='yes'; toSync.push(l); } });
  if(!toSync.length) return 0;
  const sr=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'sync',apiKey:key,leads:toSync}) });
  return sr.ok ? toSync.length : 0;
}
// v3.9: re-adding a person whose CRM row was soft-deleted (status 'deleted') must bring them BACK.
// n8n's import updates the row's FIELDS by URL match but keeps its status — without this step the
// person would stay invisible in the CRM forever. Same proven list→match→sync pattern.
async function resurrectDeletedRows(matched){
  if(!matched.length) return 0;
  const key=effectiveKey();
  const keySets=matched.map(function(l){ return liKeysOf(l); });
  const lr=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
  if(!lr.ok) return 0;
  const data=await lr.json(); const arr=(data&&Array.isArray(data.leads))?data.leads:[];
  const toSync=[];
  arr.forEach(function(l){ if(l.status!=='deleted') return; const rk=liKeysOf(l); if(keySets.some(function(ks){ return liSame(ks,rk); })){ l.status='new'; toSync.push(l); } });
  if(!toSync.length) return 0;
  const sr=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'sync',apiKey:key,leads:toSync}) });
  return sr.ok ? toSync.length : 0;
}

async function sendToN8n(isProfile){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return false; }
  const btn=document.getElementById('send-btn');
  const defLabel=isProfile?L('addToCrm'):L('sendBtn',{n:scrapedLeads.length});
  // Every lead must be filed under a campaign (= its `tags`). Block until one is chosen/typed.
  const campaign=selectedCampaign();
  if(!campaign){ setStatus('err',L('campaignRequired')); const ci=document.getElementById('ext-campaign'); if(ci) ci.focus(); if(btn){ btn.disabled=false; btn.textContent=defLabel; } return false; }
  if(btn){ btn.disabled=true; btn.textContent=L('sending'); }
  const key=effectiveKey();
  // 1) Before anything reaches the DB, check every scraped lead against Pipedrive (reuses the
  //    pipedrive-check action, no n8n change). A lead whose PERSON already exists in Pipedrive is
  //    flagged here, then later moved to status "in-pipedrive". (Org-only matches are intentionally
  //    NOT treated as "in Pipedrive" — a known company doesn't mean this specific person is a deal.)
  try{
    setStatus('loading', L('pdCheckingN',{done:0,n:scrapedLeads.length}));
    await checkLeadsInPd(scrapedLeads, function(d,n){ setStatus('loading', L('pdCheckingN',{done:d,n:n})); });
  }catch(e){ /* if the whole check fails, fall through and import normally */ }
  // 2) Read existing rows once: this powers the honest new/updated count AND tells us which
  //    person-matches are brand-NEW. We only auto-move *new* leads to "in-pipedrive" — never clobber
  //    an existing lead's status (the user asked to flag new leads; a re-scrape mustn't reset e.g. a
  //    'lead' or 'not-interested' row). `list` returns sheet rows; `import` only answers {ok:true}.
  let existing=null, a=null, u=null;
  try{
    const lr=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'list',apiKey:key}) });
    if(lr.ok){ const ld=await lr.json(); existing=(ld&&Array.isArray(ld.leads))?ld.leads:[]; }
  }catch(e){ /* unknown rows → fall back to count-less message + best-effort flagging below */ }
  // same-person lookup across URL forms (Sales-Nav id ↔ profile id ↔ /in/ slug), see liKeysOf
  const findRow=function(l){ if(!existing) return null; const ks=liKeysOf(l); return existing.find(function(r){ return liSame(ks, liKeysOf(r)); })||null; };
  // person-matched leads that are NEW to the sheet (or all person-matches if the list read failed).
  // Abbreviated last names ("Firstname L.") are excluded: their Pipedrive name-match is a guess,
  // so they import normally as `new` and get an "uncertain" note instead of auto-"in Pipedrive".
  const pdMatched=scrapedLeads.filter(function(l){ return l._pdPerson && !abbrevLastName(l.name) && (existing===null || !findRow(l)); });
  pdMatched.forEach(function(l){ if(!l.pipedrive) l.pipedrive='yes'; });
  // rows soft-deleted in the CRM that this send re-adds → resurrect after the import (v3.9)
  const resurrect=existing?scrapedLeads.filter(function(l){ const r=findRow(l); return r&&r.status==='deleted'; }):[];
  // Stamp the owner + the chosen campaign (as `tags`) + carry the pipedrive flag; strip the
  // popup-internal fields. If the person already exists under a DIFFERENT URL form (Sales-Nav
  // vs normal profile), send the STORED url instead — n8n's import matches by URL only, so this
  // makes it update that row rather than create a duplicate.
  const leadsOut=scrapedLeads.map(function(l){ const o={...l}; delete o._pdPerson; delete o._pdOrg; delete o.memberId; delete o.publicUrl;
    if(crmUser) o.sdr=[crmUser]; o.tags=[campaign];
    if(l._pdPerson&&abbrevLastName(l.name)) o.notes=(o.notes?o.notes+' • ':'')+L('pdUncertainNote');
    const row=findRow(l); if(row&&(row.url||row.linkedinUrl)) o.linkedinUrl=row.url||row.linkedinUrl;
    return o; });
  if(existing!==null){ a=0; u=0; scrapedLeads.forEach(function(l){ if(findRow(l)) u++; else a++; }); }
  if(btn) btn.textContent=L('sending');
  try {
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'import',apiKey:key,leads:leadsOut}) });
    if(resp.status===401||resp.status===403){ setStatus('err',L('invalidKey')); if(btn){btn.disabled=false;btn.textContent=L('retry');} return false; }
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    try{ await resp.json(); }catch(e){}
    // 3) Move the brand-new Pipedrive matches straight to status "in-pipedrive" in the sheet.
    let p=0;
    if(resurrect.length){ try{ await resurrectDeletedRows(resurrect); }catch(e){} }
    if(pdMatched.length){ setStatus('loading', L('pdSyncing')); try{ p=await markLeadsInPipedrive(pdMatched); }catch(e){} }
    if(btn) btn.textContent=L('sent');
    extCampaigns=null; // a new campaign may have been introduced — refresh suggestions next time
    if(a!=null && p>0) setStatus('ok',L('sentInfoPd',{a:a,u:u,p:p}));
    else if(a!=null) setStatus('ok',L('sentInfo',{a:a,u:u}));
    else if(p>0) setStatus('ok',L('sentInfoPlainPd',{n:leadsOut.length,p:p}));
    else setStatus('ok',L('sentInfoPlain',{n:leadsOut.length}));
    return true;
  } catch(e){ setStatus('err',L('sendFail')+e.message); if(btn){ btn.disabled=false; btn.textContent=L('retry'); } return false; }
}

// ── helpers ──────────────────────────────────────────────────────────────────
function esc(s){return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function updateLastScraped(ts){
  const el=document.getElementById('last-scraped');
  if(!ts){ el.textContent=L('neverScraped'); el.className='last-scraped'; return; }
  const date=new Date(ts), diff=Math.floor((Date.now()-ts)/86400000);
  const str=date.toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'})+' '+date.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});
  el.textContent=diff<7?L('scrapedOn')+str:(L('scrapedOn')+str+' ('+diff+L('daysAgo')+L('overdue')+')');
  el.className='last-scraped '+(diff<7?'recent':'overdue');
}
function setStatus(type,text){ const el=document.getElementById('status'); el.className='status-box'+(type?' '+type:''); el.textContent=text; }
function resetScrapeBtn(){ const b=document.getElementById('scrape-btn'); b.disabled=!configReady(); b.textContent=L('scrapeBtn'); }
