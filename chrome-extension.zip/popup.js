// ── n8n endpoints (prod default / test) ──────────────────────────────────────
const N8N_URLS = {
  prod: 'https://n8n.dev.hoorayhr.io/webhook/56bc510a-38d4-410f-ab5c-41ca63e825f8',
  test: 'https://n8n.dev.hoorayhr.io/webhook-test/56bc510a-38d4-410f-ab5c-41ca63e825f8'
};
let cfg = { manualKey:'', env:'prod', salesNavUrl:'', lang:'en' };
let crmKey='', crmEnv=null;
let scrapedLeads=[];
let activeTabInfo={ kind:'other', url:'' }; // kind: salesnav | profile | other

function L(k, vars){ let s=extT(cfg.lang,k); if(vars){ Object.keys(vars).forEach(n=>{ s=s.replace('{'+n+'}',vars[n]); }); } return s; }
function effectiveKey(){ return crmKey||cfg.manualKey||''; }
function effectiveEnv(){ return (crmKey&&crmEnv)?crmEnv:cfg.env; }
function effectiveUrl(){ return N8N_URLS[effectiveEnv()==='test'?'test':'prod']; }
function keySource(){ return crmKey?'CRM':(cfg.manualKey?'manual':null); }

// ── boot ──────────────────────────────────────────────────────────────────
chrome.storage.local.get(['n8nKey','n8nEnv','salesNavUrl','extLang','lastScrapedAt','n8nKeyFromCRM','n8nEnvFromCRM'], function(d){
  cfg.manualKey=d.n8nKey||''; cfg.env=d.n8nEnv==='test'?'test':'prod';
  cfg.salesNavUrl=d.salesNavUrl||''; cfg.lang=EXT_I18N[d.extLang]?d.extLang:'en';
  crmKey=d.n8nKeyFromCRM||''; crmEnv=d.n8nEnvFromCRM||null;
  document.getElementById('cfg-key').value=cfg.manualKey;
  document.getElementById('cfg-salesnav').value=cfg.salesNavUrl;
  buildLangSelect();
  applyExtI18n();
  updateKeyStatus(); updateLastScraped(d.lastScrapedAt); reflectConfigState();
  detectTab();
});

chrome.storage.onChanged.addListener(function(ch){
  if(ch.n8nKeyFromCRM||ch.n8nEnvFromCRM){
    crmKey=ch.n8nKeyFromCRM?ch.n8nKeyFromCRM.newValue||'':crmKey;
    crmEnv=ch.n8nEnvFromCRM?ch.n8nEnvFromCRM.newValue||null:crmEnv;
    updateKeyStatus(); updateEnvUI(); reflectConfigState();
  }
});

document.getElementById('settings-btn').addEventListener('click',()=>document.getElementById('settings').classList.toggle('open'));
document.getElementById('cfg-save').addEventListener('click',saveConfig);
document.getElementById('env-toggle').addEventListener('click',toggleEnv);
document.getElementById('open-sales-nav').addEventListener('click',openSalesNav);
document.getElementById('scrape-btn').addEventListener('click',scrape);
document.getElementById('profile-btn').addEventListener('click',addCurrentProfile);
document.getElementById('lang-select').addEventListener('change',function(){ cfg.lang=this.value; chrome.storage.local.set({extLang:cfg.lang}); applyExtI18n(); });

function buildLangSelect(){
  const sel=document.getElementById('lang-select');
  sel.innerHTML=Object.keys(EXT_I18N).map(c=>`<option value="${c}" ${c===cfg.lang?'selected':''}>${EXT_I18N[c]._name}</option>`).join('');
}
function applyExtI18n(){
  document.getElementById('hdr-title').textContent=L('title');
  document.getElementById('hdr-sub').textContent=L('subtitle');
  document.getElementById('lbl-settings').textContent=L('settings');
  document.getElementById('lbl-key').textContent=L('keyManualLabel');
  document.getElementById('hint-key').textContent=L('keyManualHint');
  document.getElementById('lbl-salesnav').textContent=L('salesNavLabel');
  document.getElementById('hint-salesnav').textContent=L('salesNavHint');
  document.getElementById('cfg-save').textContent=L('saveSettings');
  document.getElementById('cfg-missing').textContent=L('cfgMissing');
  document.getElementById('open-sales-nav').textContent=L('openSalesNav');
  document.getElementById('scrape-btn').textContent=L('scrapeBtn');
  document.getElementById('profile-btn').textContent=L('profileBtn');
  updateKeyStatus(); updateEnvUI(); refreshContextText();
}

function saveConfig(){
  cfg.manualKey=document.getElementById('cfg-key').value.trim();
  cfg.salesNavUrl=document.getElementById('cfg-salesnav').value.trim();
  chrome.storage.local.set({n8nKey:cfg.manualKey,salesNavUrl:cfg.salesNavUrl},()=>{
    updateKeyStatus(); reflectConfigState();
    document.getElementById('settings').classList.remove('open');
    setStatus('ok',L('settingsSaved'));
  });
}
function toggleEnv(){
  if(crmKey&&crmEnv){ setStatus('warning',L('envFollowsCRM',{env:crmEnv==='test'?'Test':'Prod'})); return; }
  cfg.env=cfg.env==='prod'?'test':'prod';
  chrome.storage.local.set({n8nEnv:cfg.env},updateEnvUI);
}
function updateEnvUI(){
  const btn=document.getElementById('env-toggle'); const env=effectiveEnv(); const locked=!!(crmKey&&crmEnv);
  btn.textContent=(env==='test'?'🧪 Test':'⚙️ Prod')+(locked?' (CRM)':'');
  btn.classList.toggle('test',env==='test');
}
function updateKeyStatus(){
  const el=document.getElementById('key-status'); const src=keySource();
  if(!src){ el.textContent=L('keyNone'); el.className='key-status none'; return; }
  if(src==='CRM'){ el.textContent=L('keyFromCRM'); el.className='key-status crm'; }
  else { el.textContent=L('keyManual'); el.className='key-status manual'; }
}
function configReady(){ return !!effectiveKey(); }
function reflectConfigState(){
  document.getElementById('cfg-missing').style.display=configReady()?'none':'block';
  document.getElementById('scrape-btn').disabled=!configReady();
  document.getElementById('profile-btn').disabled=!configReady();
}
function openSalesNav(){ chrome.tabs.create({url: cfg.salesNavUrl || 'https://www.linkedin.com/sales/search/people'}); }

// ── detect what page we're on, show the right buttons ────────────────────────
async function detectTab(){
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const url=tab?.url||'';
    if(url.includes('linkedin.com/sales/search')||url.includes('linkedin.com/sales/lists')) activeTabInfo={kind:'salesnav',url};
    else if(url.match(/linkedin\.com\/in\//)||url.includes('linkedin.com/sales/people/')||url.includes('linkedin.com/sales/lead/')) activeTabInfo={kind:'profile',url};
    else activeTabInfo={kind:'other',url};
  } catch(e){ activeTabInfo={kind:'other',url:''}; }
  // show/hide buttons
  document.getElementById('profile-btn').style.display = activeTabInfo.kind==='profile'?'flex':'none';
  document.getElementById('scrape-btn').style.display  = activeTabInfo.kind==='profile'?'none':'flex';
  refreshContextText();
}
function refreshContextText(){
  chrome.storage.local.get(['lastScrapedAt'],function(d){
    const last=d.lastScrapedAt;
    if(!configReady()){ setStatus('warning',last?contextMsg():L('welcomeNoLast')); return; }
    setStatus('', contextMsg());
  });
}
function contextMsg(){
  if(activeTabInfo.kind==='profile') return L('onProfile');
  if(activeTabInfo.kind==='salesnav') return L('onSalesNav');
  return L('onOther');
}

// ── scrape Sales Navigator list ──────────────────────────────────────────────
async function scrape(){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('scrape-btn'); setStatus('loading',L('scraping')); btn.disabled=true; btn.textContent=L('busy');
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab.url||!tab.url.includes('linkedin.com/sales')){ setStatus('err',L('goToSalesNav')); resetScrapeBtn(); return; }
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeSalesNavDOM});
    const leads=results?.[0]?.result||[];
    if(!leads.length){ setStatus('err',L('noLeads')); resetScrapeBtn(); return; }
    scrapedLeads=leads.map(l=>({...l,source:'salesnav'}));
    const now=Date.now(); chrome.storage.local.set({lastScrapedAt:now}); chrome.action.setBadgeText({text:''}); updateLastScraped(now);
    setStatus('ok','✅ '+leads.length+L('foundLeads'));
    renderResults(scrapedLeads,false);
    btn.textContent=L('rescrape'); btn.disabled=false;
  } catch(e){ setStatus('err','❌ '+e.message); resetScrapeBtn(); }
}
function scrapeSalesNavDOM(){
  const leads=[],seen=new Set();
  const selectors=['.artdeco-list__item','[data-view-name="search-results-entity-result-item"]','li.artdeco-list__item'];
  let items=[]; for(const sel of selectors){ items=Array.from(document.querySelectorAll(sel)); if(items.length)break; }
  if(!items.length){ const cards=new Set(); document.querySelectorAll('a[href*="/sales/people/"],a[href*="/sales/lead/"]').forEach(link=>{ const c=link.closest('li')||link.closest('[class*="result"]')||link.closest('[class*="item"]'); if(c)cards.add(c); }); items=Array.from(cards); }
  items.forEach(item=>{ try{
    const nameEl=item.querySelector('[data-anonymize="person-name"], .artdeco-entity-lockup__title span');
    const name=nameEl?.innerText?.trim(); if(!name||name.length<2||seen.has(name))return; seen.add(name);
    const titleEl=item.querySelector('[data-anonymize="title"], .artdeco-entity-lockup__subtitle');
    const titleRaw=titleEl?.innerText?.trim()||''; const parts=titleRaw.split('·'); const title=parts[0]?.trim()||titleRaw;
    const companyEls=item.querySelectorAll('[data-anonymize="company-name"], .artdeco-entity-lockup__caption');
    let newCompany=parts[1]?.trim()||''; let oldCompany='';
    if(companyEls[0])newCompany=companyEls[0].innerText.trim()||newCompany;
    if(companyEls[1])oldCompany=companyEls[1].innerText.trim();
    const linkEl=item.querySelector('a[href*="/sales/people/"],a[href*="/sales/lead/"]');
    leads.push({name,title,newCompany,oldCompany,size:'',linkedinUrl:linkEl?.href||''});
  }catch(e){} });
  return leads;
}

// ── add a single normal-LinkedIn profile ─────────────────────────────────────
async function addCurrentProfile(){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('profile-btn'); btn.disabled=true; btn.textContent=L('busy');
  try {
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:scrapeProfileDOM});
    const lead=results?.[0]?.result;
    if(!lead||!lead.name){ setStatus('err',L('couldNotRead')); btn.disabled=false; btn.textContent=L('profileBtn'); return; }
    lead.source='profile'; lead.linkedinUrl=lead.linkedinUrl||tab.url;
    scrapedLeads=[lead];
    setStatus('ok',L('profileAdded',{name:lead.name}));
    renderResults(scrapedLeads,true);
    // auto-send single profile immediately
    await sendToN8n(true);
    btn.disabled=false; btn.textContent=L('profileBtn');
  } catch(e){ setStatus('err','❌ '+e.message); btn.disabled=false; btn.textContent=L('profileBtn'); }
}
function scrapeProfileDOM(){
  function txt(sel){ const el=document.querySelector(sel); return el?el.innerText.trim():''; }
  // Normal LinkedIn profile
  let name = txt('h1');
  let title = txt('div.text-body-medium') || txt('[data-generated-suggestion-target] .text-body-medium');
  let company='';
  // "Experience" current company often in aria or the top card
  const exp=document.querySelector('[aria-label*="Current company"], button[aria-label*="Current company"]');
  if(exp) company=exp.innerText.trim();
  if(!company){ const li=document.querySelector('section.pv-profile-section .pv-entity__secondary-title, .pvs-entity__caption-wrapper'); if(li) company=li.innerText.trim(); }
  // Sales Navigator profile fallback
  if(!name){ name=txt('[data-anonymize="person-name"]'); title=txt('[data-anonymize="title"]'); company=txt('[data-anonymize="company-name"]'); }
  return { name, title, newCompany:company, oldCompany:'', size:'', linkedinUrl: location.href.split('?')[0] };
}

// ── results + send ────────────────────────────────────────────────────────────
function renderResults(leads,isProfile){
  const el=document.getElementById('results'); el.innerHTML='<hr class="divider">';
  if(!isProfile){
    const sendBtn=document.createElement('button'); sendBtn.className='btn btn-green'; sendBtn.id='send-btn';
    sendBtn.textContent=L('sendBtn',{n:leads.length}); sendBtn.addEventListener('click',()=>sendToN8n(false)); el.appendChild(sendBtn);
  }
  const hdr=document.createElement('div'); hdr.className='results-header';
  hdr.textContent=leads.length+L('preview')+' — '+(effectiveEnv()==='test'?'🧪 Test':'⚙️ Prod'); el.appendChild(hdr);
  leads.slice(0,3).forEach(l=>{ const c=document.createElement('div'); c.className='lead-card';
    c.innerHTML='<div class="lc-name">'+esc(l.name)+'</div><div class="lc-sub">'+esc(l.title||'—')+'</div><div class="lc-company">'+esc(l.newCompany||'')+'</div>'; el.appendChild(c); });
  if(leads.length>3){ const m=document.createElement('div'); m.className='more'; m.textContent='+'+(leads.length-3); el.appendChild(m); }
}
async function sendToN8n(isProfile){
  if(!configReady()){ document.getElementById('settings').classList.add('open'); return; }
  const btn=document.getElementById('send-btn'); if(btn){ btn.disabled=true; btn.textContent=L('sending'); }
  const key=effectiveKey();
  try {
    const resp=await fetch(effectiveUrl(),{ method:'POST', headers:{'Content-Type':'application/json','X-API-Key':key}, body:JSON.stringify({action:'import',apiKey:key,leads:scrapedLeads}) });
    if(resp.status===401||resp.status===403){ setStatus('err',L('invalidKey')); if(btn){btn.disabled=false;btn.textContent=L('retry');} return; }
    if(!resp.ok) throw new Error('HTTP '+resp.status);
    let info={}; try{ info=await resp.json(); }catch(e){}
    const a=info.added!=null?info.added:scrapedLeads.length, u=info.updated!=null?info.updated:0;
    if(btn) btn.textContent=L('sent');
    setStatus('ok',L('sentInfo',{a:a,u:u}));
  } catch(e){ setStatus('err',L('sendFail')+e.message); if(btn){ btn.disabled=false; btn.textContent=L('retry'); } }
}

// ── helpers ──────────────────────────────────────────────────────────────────
function esc(s){return (s==null?'':String(s)).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}
function updateLastScraped(ts){
  const el=document.getElementById('last-scraped');
  if(!ts){ el.textContent=L('neverScraped'); el.className='last-scraped'; return; }
  const date=new Date(ts), diff=Math.floor((Date.now()-ts)/86400000);
  const str=date.toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'})+' '+date.toLocaleTimeString(undefined,{hour:'2-digit',minute:'2-digit'});
  el.textContent=diff<7?L('scrapedOn')+str:(L('scrapedOn')+str+' ('+diff+L('daysAgo')+L('overdue')+')');
  el.className='last-scraped '+(diff<7?'recent':'overdue');
}
function setStatus(type,text){ const el=document.getElementById('status'); el.className='status-box'+(type?' '+type:''); el.textContent=text; }
function resetScrapeBtn(){ const b=document.getElementById('scrape-btn'); b.disabled=!configReady(); b.textContent=L('scrapeBtn'); }
